/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemploarraylist;

/**
 *
 * @author JoLuuu
 */
public class Carro {
    private String placa;
    private int modelo;
    private String color;
    private String version;
    private String marca;
    private Usuario propietario;
 //   private Map<Usuario> Carro;

    public Usuario getPropietario() {
        return propietario;
    }

    public void setPropietario(Usuario propietario) {
        this.propietario = propietario;
    }




    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
   public class Principal{
       public static void main(String[] args) {
        
           
           
           
           //para crear un arreglo 
           int modeloDeAutos[] = new int[5];
           
           System.out.println(modeloDeAutos[0]);
           System.out.println(modeloDeAutos[1]);
           System.out.println(modeloDeAutos[2]);
           System.out.println(modeloDeAutos[3]);
           System.out.println(modeloDeAutos[4]);
       
           
           modeloDeAutos[3]= 2001;
           //para editar el cntenido del arreglo    
           
           String MarcasCarros[]= {"tollota","maikra","lol","ñpñ"};
       
          
           for (int i = 0; i < MarcasCarros.length; i++) {
               String m = MarcasCarros[i];
               System.out.println(i);
           }
           
           
           for(String m : MarcasCarros){
               
               
           }
           
           
           
           
                   
       }
       
       
       
   }
    
    
    
}
