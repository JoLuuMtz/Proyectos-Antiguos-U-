/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioclase3;
import java.util.Scanner;


public class EjercicioClase3 {

    
    public static void main(String[] args) {
        
        System.out.println("Veamos la distancia para llegar a la casa de mi amigo");
	System.out.println("Mi amigo se encuentra en el punto X en las coordenadas 5");
	System.out.println(" digite el punto donde se encuentra en el punto Y ");
	float X = 5;
	Scanner teclado = new Scanner (System.in);
	float Y = teclado.nextFloat();
	
	float distancia = X-Y; 
        
	if (distancia<0){
		distancia *= -1;
	}
	System.out.println("La distancia entre el punto X y el punto Y es de "+distancia+" KM");
	
		
    }
    
}
