/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;


public class Congreso {
    private String Chaiman;

    public String getChaiman(){
        return Chaiman;
    }
    
  public void setChaiman(String Chaiman){
      
     this.Chaiman = Chaiman;
    }
   

  
    
    
    
    
}
