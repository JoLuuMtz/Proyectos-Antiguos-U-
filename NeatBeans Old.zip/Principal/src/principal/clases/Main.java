/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.TemporalQueries;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import principal.clases.Personas;
import principal.clases.Congresistas;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import principal.clases.Sesion;

public class Main {
    public static void main(String[] args) {
        
          Personas p = new Personas();
         //Personas
     p.setNombre("JORGE LUIS");
     p.setApellido("Martinez");
     p.setApellido2("RICARDO");
     p.setId(123);
     p.setEmail("jorgemartinezircardo@gmail.com");
     p.setInsituto("Universidadd el Sinu Elyas bechara Cartagena");
     p.setTelefono("3115849674");
     //SALA
     Sala s = new Sala();
     s.setHora("12:30");
     SimpleDateFormat dtf = new SimpleDateFormat("yyyy/MM/dd");
     Calendar calendar = Calendar.getInstance();
     Date date = calendar.getTime();
     String formattedDate = dtf.format(date);
     s.setFecha(date);
     //trabajo
     Trabajo T = new Trabajo();
   
     T.setTitulo("Derivacion de la papaya");
     T.setDescripcion("Se establecera una breve descripcion acercad e la papaya"
     + "/n de forma momentanea y establecera nuevos camninoa alimenticios ");
//aUTORES

     Autores A = new Autores();
     A.setNombre("* Autores *");
     A.setApellido("ApelliDO Autores");
     A.setPonentes("*Ponentes*"); 
     A.setAsistio(true);
  //   T.setAutoresAsociados((List<Autores>)A);  
   
     //Session
     Sesion e = new Sesion();
     e.setFecha(date);
     e.setHora("12:30");
     
    // T.setSession((List<Sesion>)e);
    
     Congreso C = new Congreso();
     
     C.setChaiman("Persona Encargada");
     Congresistas Co = new Congresistas();
   // Co.setRegistro((List<Personas>) p);
        System.out.println("La siguiente persona estara en la reunion del congreso");
        System.out.println("oprima enter para ver los datos ");
        Scanner teclado = new Scanner (System.in);
        String na = teclado.nextLine();
       System.out.println("ID congresista "+p.getId());
        System.out.println("Nombre "+p.getNombre());
        System.out.println("Apellidos "+p.getApellido()+" "+p.getApellido2());
        System.out.println("Correo "+p.getEmail());
        System.out.println("Telefono "+p.getTelefono());
        System.out.println("La fecha de la reunion sera"+e.getFecha()+""
                + "a la hora"+e.getHora()+" En la sala "+e.getSala());
        System.out.println("EL trabajo a tratar sera el siguiente"+T.getDescripcion());
        System.out.println("El cual llevara por titulo "+ T.getTitulo());
        System.out.println("El encargado sera "+A.getNombre()+" con la ayuda de "+A.getPonentes());
        
        
     
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
      
      
}   
  }
         
   
        
        
      
   
       
            
            
            
            
            
       
            
         
           

