/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;

import java.util.List;


public class Trabajo {
    
   private float id;  
   private String titulo;
   private String descripcion;
   private List<Sesion> session;
   private List<Autores> AutoresAsociados;

    public List<Autores> getAutoresAsociados() {
        return AutoresAsociados;
    }

    public void setAutoresAsociados(List<Autores> AutoresAsociados) {
        this.AutoresAsociados = AutoresAsociados;
    }
   

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Sesion> getSession() {
        return session;
    }

    public void setSession(List<Sesion> session) {
        this.session = session;
    
    }
}
