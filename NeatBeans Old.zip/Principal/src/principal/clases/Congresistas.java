/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;

import java.util.List;

public class Congresistas {
    private List<Personas>Registro; 

    public List<Personas> getRegistro() {
        return Registro;
    }

    public void setRegistro(List<Personas> Registro) {
        this.Registro = Registro;
    }

   
    
}
