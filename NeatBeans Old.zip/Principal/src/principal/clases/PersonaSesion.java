/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;

import java.util.List;


 class PersonaSesion {
    private float id;
    private List<Personas> personas;
    private List<Sesion>session;

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public List<Personas> getPersonas() {
        return personas;
    }

    public void setPersonas(List<Personas>personas) {
        this.personas = personas;
    }

    public List<Sesion> getSession() {
        return session;
    }

    public void setSession(List<Sesion> session) {
        this.session = session;
    }
     
     
     
}
