/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal.clases;


 public class TipoPersona {
  private float id;
  private String Tipo_Personas;

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getTipo_Personas() {
        return Tipo_Personas;
    }

    public void setTipo_Personas(String Tipo_Personas) {
        this.Tipo_Personas = Tipo_Personas;
    }
  
     
     
     
}
