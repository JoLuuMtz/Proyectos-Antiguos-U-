/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PAGOS_DE_SUELDOS;

/**
 *
 * @author jhonda
 */
public class Main {

    public static void main(String[] args)  {
        Ventana ventana = new Ventana();
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);

    }

}
