/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioclase1;
import java.util.Scanner;
public class EjercicioClase1 {

    public static void main(String[] args) {
  
		System.out.print("Ingrese un numero: ");
		Scanner teclado = new Scanner (System.in);
		int N1 = teclado.nextInt();
		System.out.print("Ingrese el segundo numero a sumar: ");
		int N2 = teclado.nextInt();
		int resultado = N2+N1;

		System.out.print("El resultado de los dos numeros \n ingresados es: "+resultado);
    }
    
}
