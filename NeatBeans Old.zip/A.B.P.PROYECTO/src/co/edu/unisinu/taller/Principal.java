package co.edu.unisinu.taller;
//co.edu.unisinu.taller.Principal;

import co.edu.unisinu.taller.Interface.Ventana1;

public class Principal {
    public static void main(String[] arg){
        Ventana1 ventanaP = new Ventana1();
        ventanaP.setLocationRelativeTo(null);
        ventanaP.setVisible(true);
    }
}
