/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.de.arreglos;

public class EjercicioDeArreglos {

    public static void main(String[] args) {

        String Asignaturas[] = new String [7];
       Asignaturas [0] = "Desarrollo I";
       Asignaturas [1] = "Calculo I";
       Asignaturas [2] = "Mantenimiento";
       Asignaturas [3] = "Fundamentos De Sistemas";
       Asignaturas [4] = "REDES I";
       Asignaturas [5] = "Algebra Lineal";
       Asignaturas [6] = "Optativa";
      
       
       float Notas1[]= new float [7];
       Notas1 [0]= 5;
       Notas1 [1]= 1.1f;
       Notas1 [2]= 4;
       Notas1 [3]= 2;
       Notas1 [4]= 3;                   
       Notas1 [5]= 5;    
       Notas1 [6]= 4;  
       
       
        for (int i = 0; i <= Notas1.length; i++) {
            System.out.println("Asigantura "+Asignaturas[i]+ ":"+Notas1[i]);
            
        }
       
       
       
               
              
       
       
       
          
          
          
          
          
          
    }
    
}
