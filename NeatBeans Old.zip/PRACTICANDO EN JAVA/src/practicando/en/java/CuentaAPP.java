/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicando.en.java;
import java.util.*;


public class CuentaAPP {
    public static void main(String[] args) {
       Cuenta c1 = new Cuenta("");
       Cuenta c2 = new Cuenta("");
      
       c1.ingresar(300);
       c2.ingresar(400);
       
       c1.retirar(500);
       c2.retirar(100);
        System.out.println(c1);
        System.out.println(c2);
        System.out.println("Buen uso de los contructores ");
        
        
        
        
    }
    
    
    
    
   
}
