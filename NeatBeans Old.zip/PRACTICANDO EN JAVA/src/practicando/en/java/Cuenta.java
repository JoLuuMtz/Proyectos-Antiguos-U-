
package practicando.en.java;


public class Cuenta {
    private String titular;
    private float cantidad;

public Cuenta(String t)  {
    titular = t;
}
public Cuenta(float c){
    cantidad = c;
    
}
public Cuenta (String titular, float cantiad){
    this.titular = titular;
    if(cantidad< 0){
        this.cantidad = 0;
    }
    else{
         this.cantidad = cantidad;
      }

 } 
  public String gettitular(){
      
        return titular;
  }
  public void settitular(String titular){
      this.titular = titular;
  }
  public float getcantidad(){
      return cantidad;
  }    
  public void setcantidad(float cantidad){
   this.cantidad = cantidad;
 }
 public void ingresar(float cantidad){
    if (cantidad > 0){
        this.cantidad +=cantidad;
    }
 }
 public void retirar(float cantidad){   
     if (this.cantidad - cantidad < 0){
         this.cantidad=0;
     }else{
        this.cantidad -= cantidad;
     }
 } 
 public String toString(){
     return "Titular" + titular + "tiene" + cantidad + "dolares en la cuenta";
 }
 
    
    
    
    
 }
  
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    

