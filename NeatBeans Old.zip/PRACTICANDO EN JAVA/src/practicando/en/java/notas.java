/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practicando.en.java;

/**
 *
 * @author DELL
 */
public class notas {
    
   private int nota1;
   private int nota2;
   private int nota3;
  
   

public notas(int N1, int N2, int N3){

    nota1 = N1;
    nota2 = N2;
    nota3 = N3; 
}

    public int getNota1() {
        return nota1;
    }

    public void setNota1(int nota1) {
        this.nota1 = nota1;
    }

    public int getNota2() {
        return nota2;
    }

    public void setNota2(int nota2) {
        this.nota2 = nota2;
    }

    public int getNota3() {
        return nota3;
    }

    public void setNota3(int nota3) {
        this.nota3 = nota3;
    }
    

}






    
