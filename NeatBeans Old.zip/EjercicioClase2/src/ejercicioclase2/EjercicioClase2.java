/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioclase2;
import java.util.Scanner;
/**
 *
 * @author DELL
 */
public class EjercicioClase2 {

   
    public static void main(String[] args) {
        
 		System.out.println("Convirtamos medidas");
		System.out.print("Ingrese la medida en Kilometros: ");
		Scanner teclado = new Scanner (System.in);
		int KM = teclado.nextInt();
		int centimetros = KM*100000;
		int metro = KM*1000;
		
		System.out.println("La medida de "+KM+" Kilometros Equivale a "+centimetros+" centimetros");
		System.out.println("La medida de "+KM+" Kilometros  Equivale a "+metro+" Metros");
    }
    
}
