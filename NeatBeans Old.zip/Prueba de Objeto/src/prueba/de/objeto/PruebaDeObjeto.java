/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prueba.de.objeto;


public class PruebaDeObjeto {

    public static void main(String[] args) {

        int n2 = 2;
        int n1= 8;
        int r = n2+n1;
        
        if(r==10){
    
        
            }
    
}

    
}


    

