/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ControladorCarros;

import Vistas.persona.VentanaAgregarCarros;
import Vistas.persona.VentanaBuscarCarros;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Float.parseFloat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import java.util.*;
import Carros.Modelo.Carros;


public class ControlCarros implements ActionListener{
 private JDialog objetoVistaActual;
 private Carros objetoPersona;

 
 public ControlCarros(JDialog ventana){
     this.objetoVistaActual = ventana;
 }
    // El código que se escriba aquí se ejecutara automáticamente
// cada vez que ocurre un ActionEvent generado por
// alguno de los componentes vigilados por este Manejador.
@Override
public void actionPerformed(ActionEvent evento) {
// obtener la el Comando o la Acción
String comandoAccion = evento.getActionCommand();
// preguntar si el comando es agragar_persona
if (comandoAccion.equals("agregar_persona")) {
this.accionAgregarCarro(evento);
}

else if (comandoAccion.equals("buscar_persona")) {
accionBuscarCarro(evento);

}

else if (comandoAccion.equals("borrar_persona")) {
this.accionBorrarPersona(evento);

}

else if (comandoAccion.equals("editar_persona")) {
this.accionEditarPersona(evento);

}

else if (comandoAccion.equals("listar_persona")) {
this.accionListarPersona(evento);
}
else if(comandoAccion.equals("cancelar")){
    this.accionCancelar(evento);
}


}

// FUNCION QUE REALIZA LA ACCION DE AGREGAR UNA PERSONA A LA AGENDA
public void accionAgregarCarro(ActionEvent evento) {
    

VentanaAgregarCarros vista = (VentanaAgregarCarros) objetoVistaActual;

String id = vista.getCampoId().getText();
String nombre = vista.getCampoNombre().getText();
String apellido = vista.getCampoApellido().getText();
String genero = (String) vista.getComboGenero().getSelectedItem();
String nacimiento = vista.getCampoFechaDeNacimiento().getText();
String email = vista.getCampoEmail().getText();
String telefono = vista.getCampoTelefono().getText();
String direccion = vista.getCajaDireccion().getText();
// crear el objeto de la clase Carros
this.objetoPersona = new Carros();
// setear sus propiedades con los datos introducidos en la vista
this.objetoPersona.setId(id);
this.objetoPersona.setNombre(nombre);
this.objetoPersona.setApellido(apellido);
this.objetoPersona.setGenero(genero);
// pasar la fecha de String a Date
Date fechaDeNacimiento = null;
SimpleDateFormat formateadorDeFecha = new SimpleDateFormat("YYYY-M-DD");
   int Id2 = 0;
   int Tel2 =0;
   int  G = 0; 
//validacion de email
if(direccion.isEmpty()) {
           direccion = "Sin casa";
       }   
    if(email.isEmpty()){
           email = "sinemail@sinemail.com";
       }
      Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
      Matcher mather = pattern.matcher(email);
       if (mather.find() == false) {
           try {
                 Id2 = Integer.parseInt(email);
                  this.objetoPersona.setEmail(email); ;
           } catch (Exception e) {
               vista.mostrarMensaje("Ingrese Email Correcto");
               return;
           }
        } 
 
    try { //validacio ID
      
        Id2 = Integer.parseInt(id);
       this.objetoPersona.setId(id);
    } catch (Exception e ) {
        vista.mostrarMensaje("El Id debe ser numeros");
        return;
    }
    boolean T = false;
  //valdiacion telefono
  if(telefono.isEmpty()){
      T = true;
  }
  if(T == true){
      telefono = "Sin placa";
  }
  if(T==false){
     try {
        Tel2 = Integer.parseInt(telefono);
       this.objetoPersona.setTelefono(telefono);
    } catch (Exception e) {
        vista.mostrarMensaje("El telefono debe ser numero");
        return;
    }
  }
     //validacion comoGenero
     if(genero.equals("Seleccione un ...")){
        try {
       G = Integer.parseInt(genero);
       this.objetoPersona.setGenero(genero);
    } catch (Exception e) {
        vista.mostrarMensaje("Elija un Estado");
        return;
}
     }
     
try {

fechaDeNacimiento = formateadorDeFecha.parse(nacimiento);
this.objetoPersona.setFechaNacimiento(fechaDeNacimiento);
}
catch (ParseException error) {
vista.mostrarMensaje("Para poder continuar por favor digite una fecha valida");

return;
}


this.objetoPersona.setEmail(email);
this.objetoPersona.setDireccion(direccion);
// ahora guardamos la persona
//objeto.guardarEnDisco(); // aun no esta definida
// mostramos un mensaje de satisfacción en la Vista
  try {
// guardamos la persona mientras el try vigila
objetoPersona.guardarEnDisco();
}
catch (Exception error) {
//Si ocurre una Exception entonces mostramos un mensaje
vista.mostrarMensaje("Error al Guardar esta Persona\n"
+error.getMessage());
}
// mostramos un mensaje de satisfaccion
vista.mostrarMensaje("Se agrego El carro "+objetoPersona.devolverDatos()+ " En el Archivo");



//vista.mostrarMensaje("Se agrego la siguiente persona en la agenda:\n"+ objetoPersona.devolverDatos());

    vista.BorrarCasillas();

    
}
public void accionBuscarCarro(ActionEvent evento) {
    VentanaBuscarCarros ventana = (VentanaBuscarCarros)this.objetoVistaActual;
        String id = JOptionPane.showInputDialog(this.objetoVistaActual,"Dijite el ID deL CARRO: ");
        if(id == null || id.trim().length() <= 0){
            ventana.mostrarMensaje("Debes Agregar una ID Valida");
            return; 
        }else {
            try{
                this.objetoPersona = Carros.buscarCarro(id);
                ventana.getCampoId().setText(objetoPersona.getId());
                ventana.getCampoNombre().setText(objetoPersona.getNombre());
                ventana.getCampoApellido().setText(objetoPersona.getApellido());
                ventana.getCampoEmail().setText(objetoPersona.getEmail());
                ventana.getCampoTelefono().setText(objetoPersona.getTelefono());
                ventana.getCajaDireccion().setText(objetoPersona.getDireccion());
                SimpleDateFormat formateadorFecha = new SimpleDateFormat("dd-mm-yyyy");
                String fechaN = formateadorFecha.format(objetoPersona.getFechaNacimiento());
                ventana.getCampoFechaDeNacimiento().setText(fechaN);
                ventana.getComboGenero().setSelectedItem(objetoPersona.getGenero());
            
            }catch(Exception error){
                ventana.mostrarMensaje(error.getMessage());
                return;
        
            }
        }
    
    }


public void accionBorrarPersona(ActionEvent evento) {

}
public void accionEditarPersona(ActionEvent evento) {

}
public void accionListarPersona(ActionEvent evento) {

}
public void accionCancelar(ActionEvent evento){
this.objetoVistaActual.dispose();

}


    

    
  
    
    
    
    

}
   
























