/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vistas;
import Vistas.persona.VentanaAgregarCarros;
import Vistas.persona.VentanaBuscarCarros;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author JoLuuu
 */
public class VentanaPrincipal extends JFrame{
    
    
    private JMenuBar barraMenu;
    private JMenu menuSesion;
    private JMenu menuCarro;
    private JMenu menuInvitaciones;
    private JMenu menuEventos;
    private JMenu menuAyuda;
    //Sesion
    private JMenuItem opcionMenuIniciarSesion;
    private JMenuItem opcionMenuCerrarSesion;
    private JMenuItem opcionMenuSalirSesion;
    //persona
    private JMenuItem opcionMenuAgregarPersona;
    private JMenuItem opcionMenuBuscarPersona;
    private JMenuItem opcionMenuBorrarPersona;
    private JMenuItem opcionMenuEditarPersona;
    //lista persona
    private JMenu subMenuListarPersonas;
    private JMenuItem opcionListarPersonasPorNombre;
    private JMenuItem opcionListarPersonasPorApellido;
    private JMenuItem opcionListarPersonasPorGenero;
    private JMenuItem opcionListarPersonasPorFechaDeNacimiento;
    private JMenuItem opcionListarPersonasPorEvento;
    //eventos
    private JMenuItem opcionMenuAgregarEventos;
    private JMenuItem opcionMenuBorrarEventos;
    private JMenuItem opcionMenuBuscarEventos;
    private JMenuItem opcionMenuEditarEventos;
    //listaEventos
    private JMenu subMenuListarEventos;
    private JMenuItem opcionListarEventosPorPersona;
    private JMenuItem opcionListarEventosPorFecha;
    //invitados
    private JMenuItem opcionMenuAgregarInvitado;
    private JMenuItem opcionMenuEditarInvitado;
    private JMenuItem opcionMenuBuscarInvitado;
    private JMenuItem opcionMenuBorrarInvitado;
    //lista invitar
    private JMenu subMenuListarInvitados;
    private JMenuItem opcionListarInvitadosPorPersona;
    private JMenuItem opcionListarInvitadosPorEventos;
      
    
      
//este codigo es para arregar item por item cada menu en la ventana JFrame
    public VentanaPrincipal(){
  this.configurar();
    }  
    public void configurar(){
        
        this.barraMenu = new JMenuBar();
        this.setJMenuBar(barraMenu);
        this.menuSesion = new JMenu("Session");
        this.menuSesion.setMnemonic('S');
        this.barraMenu.add(menuSesion);
        this.opcionMenuIniciarSesion = new JMenuItem("Iniciar");
        this.opcionMenuCerrarSesion = new JMenuItem("Cerrar");
        this.opcionMenuSalirSesion = new JMenuItem("Salir");
                
//paara agregar item al menu de session
        this.menuSesion.add(this.opcionMenuIniciarSesion);
        this.menuSesion.add(this.opcionMenuSalirSesion);
        this.menuSesion.add(this.opcionMenuCerrarSesion);
        
        //Agregar el menu de Peronsas y sus repscetivos item
        
        
        this.menuCarro = new JMenu("Carro");
        //agregar el menu persona en la barra
         this.barraMenu.add(this.menuCarro);
        this.menuCarro.setMnemonic('P');
        this.opcionMenuAgregarPersona = new JMenuItem("Agregar");
        this.opcionMenuBorrarPersona = new JMenuItem("Borrar");
        this.opcionMenuEditarPersona = new JMenuItem ("Editar");
        this.opcionMenuBuscarPersona = new JMenuItem ("Buscar");
        //Agregar menuItem al menu de Persona
        this.menuCarro.add(opcionMenuAgregarPersona);
         this.menuCarro.add(opcionMenuEditarPersona);
         this.menuCarro.add(opcionMenuBuscarPersona);
         this.menuCarro.add(opcionMenuBorrarPersona);
         //Agreagr el subMenu Lista para el Mneu Persona
    
      this.menuAyuda = new JMenu ("Ayuda");
      this.barraMenu.add(this.menuAyuda);

    ActionListener eventoAgregarPersona = new ActionListener() {
@Override
public void actionPerformed(ActionEvent evento) {
mostrarVentanaAgregarPersona(evento);
}
};
this.opcionMenuAgregarPersona.addActionListener(eventoAgregarPersona);
ActionListener eventoBuscarPersona = new ActionListener() {
@Override
public void actionPerformed(ActionEvent evento) {
mostrarVentanaBuscarPersona(evento);
}
};
this.opcionMenuBuscarPersona.addActionListener(eventoBuscarPersona);
}
public void mostrarVentanaAgregarPersona( ActionEvent evento ){
VentanaAgregarCarros VentanaAgrgaeP = new VentanaAgregarCarros(this);
VentanaAgrgaeP.setLocationRelativeTo(this);
VentanaAgrgaeP.setVisible(true);
}


public void mostrarVentanaBuscarPersona( ActionEvent evento ){
VentanaBuscarCarros VentanaBuscarP = new VentanaBuscarCarros(this);
VentanaBuscarP.setLocationRelativeTo(this);
VentanaBuscarP.setVisible(true);
}

    }
    

     
     
     
     
      
      
      
    
        
        
    

