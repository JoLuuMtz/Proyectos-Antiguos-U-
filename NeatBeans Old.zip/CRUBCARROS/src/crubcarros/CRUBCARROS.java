/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package crubcarros;
import javax.swing.JFrame;
import static java.lang.reflect.Array.get;



import Vistas.VentanaPrincipal;
/**
 *
 * @author JoLuuu
 */
import Vistas.VentanaPrincipal;
import javax.swing.JFrame;
public class CRUBCARROS {

   
    public static void main(String[] args) {
       VentanaPrincipal  V = new VentanaPrincipal();
   V.setVisible(true);
   V.setExtendedState(JFrame.MAXIMIZED_BOTH);
   V.setTitle("Agenda Electornica");
        
    }
    
}
