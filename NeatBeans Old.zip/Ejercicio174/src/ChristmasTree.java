import java.util.Scanner;

public class ChristmasTree {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce la altura del árbol de Navidad: ");
        int height = scanner.nextInt();

        // Dibuja la parte superior del árbol
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < height - i - 1; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        // Dibuja el tronco del árbol
        for (int i = 0; i < height / 3; i++) {
            for (int j = 0; j < height - 1; j++) {
                System.out.print(" ");
            }
            System.out.println("|");
        }
    }
}
