/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicios;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Ejercicio174 {

    public static void main(String[] args) {
          
        
        String cargo = "ADMINISTRADOR";
        System.out.println(cargo);
        StringBuilder c = new StringBuilder(cargo);
        cargo = c.reverse().toString();
        System.out.println(cargo);
  
	String str = "DelfStack";
        System.out.println(str);
		StringBuilder strb = new StringBuilder(str);
		str = strb.reverse().toString();
		System.out.println(str);
	

      /*  
        Scanner teclado = new Scanner(System.in);
        System.out.println("NOMBRE ");
        String nombre = teclado.nextLine();
        System.out.println("apellido1");
        String  apellido1 = teclado.nextLine();
        System.out.println("apellido2");
        String  apellido2 = teclado.nextLine();
        System.out.println("cargo");
        String  cargo = teclado.nextLine();
        char letra1 = cargo.charAt(0);
        char letra2 = cargo.charAt(1);
        char ultimaapellido2 = apellido2.charAt(apellido2.length()-1);
        char primeraapellido2 = apellido2.charAt(0);
        char ultimaapellido1 = apellido1.charAt(apellido1.length()-1);
        char primeraapellido1 = apellido1.charAt(0);
    
        
        System.out.println (letra1+letra2+primeraapellido1+ultimaapellido1+nombre+primeraapellido2+ultimaapellido2);
   */

    }
    
}
