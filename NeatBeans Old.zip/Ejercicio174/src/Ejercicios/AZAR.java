/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

public class AZAR {

    public static void main(String[] args) {

        int random = (int) (Math.random() * 255);
        System.out.println(random);

    }

}
