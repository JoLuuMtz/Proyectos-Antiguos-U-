/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicios;

import java.util.Scanner;

/**
 *
 * @author JoLuuu
 */
public class lol {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
       int n=0;
        int r=0;
        
         while(true){
        n= teclado.nextInt();
        r = r+n;
    if((n>20 && n<=30) || (n==0)){
        break;
    }
         }
        System.out.println(r);
      
    }
}
