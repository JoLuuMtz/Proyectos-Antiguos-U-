/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package asterisco;

import java.util.*;
import javax.swing.JOptionPane;

public class Asterisco {
    public static void main(String[] args) {
        boolean error = true;
        String opcion = "";
       int NMulti = 0;
       int resultado;
        do{
      
        final String Yo = "JorgeBotQuestion´s";
        //El uso de const es el mismo que final
        System.out.println("Buenas soy "+Yo+" Y voy ");
        System.out.println("recolectar algunos datos tuyos");
        System.out.println("Cuantos años tiene?");
        Scanner teclado = new Scanner (System.in);
        byte edad = teclado.nextByte();
        System.out.println("Cuantos abuelos tienes?");
        short abuelo = teclado.nextShort();
        System.out.println("Cuantas abuelas tienes?");
        int abuela = teclado.nextInt();
        System.out.println("Cuantas veces comes al mes?");
        long comer = teclado.nextLong();
        System.out.println("Cuanto mides?");
        float estatura = teclado.nextFloat();
        System.out.println("Cuantos amigos tienes?");
        double amigos = teclado.nextDouble();
        System.out.println("Escriba cualquier palabra y el sistema n/tomara la tercera letra de esa palabra,?");
        char a = teclado.next().charAt(2);
        teclado = new Scanner (System.in);
            System.out.println("Bueno ahora te hare una pregunta");
            System.out.println("como te llevas con tus padres?");
            System.out.println("Bien o Mal?");
            String bien = teclado.nextLine();
            bien = bien.toLowerCase();
            boolean pregunta1=false;
            do{
           switch (bien){
               case "bien":
                   System.out.println("Pefecto, Me alegro");
                   break;
           case "mal":
           System.out.println("Eso se puede arreglar si lo deseas");
           break;
           
           default:
               System.out.println (" Elije una de las opciones, por favor");
               if(bien!="bien" && bien!="mal"){
                       pregunta1 = true;
                }
                else {
                   break;
                }
           }
         do{
           System.out.println("Bueno ahora elige un numero \n el cual sera multiplicado del 1 al 10");  
              try{
           teclado = new Scanner (System.in);  
           NMulti = teclado.nextInt();  
       break;
              }catch(InputMismatchException e){
                      System.out.println("Ingrese numeros\n las letras no se multiplican ");
                      }
             }while(error);   
             for(int i = 0 ; i<11; i++){
                 resultado = NMulti*i;
                 System.out.println(NMulti+"x"+i+"="+resultado);
              if(i==10){
                  break;
              }   
              if(i>0){
                  continue;
              }
                       } 
           
             
          
            }while(pregunta1==true);
           
            System.out.println("Hay mas Personas por entrevistar?");
            teclado = new Scanner(System.in);
             opcion = teclado.nextLine();
             opcion = opcion.toLowerCase();
        }while(opcion.equals("si"));
        
        JOptionPane.showMessageDialog(null,"Todo se ha guardado en \n la base de datos");
        JOptionPane.showMessageDialog(null,"LISTO, MUCHAS GRACIAS!" );
        
        
    }
    
}
