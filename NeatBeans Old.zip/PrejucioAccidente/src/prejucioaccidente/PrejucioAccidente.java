/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prejucioaccidente;
import java.util.Scanner;

public class PrejucioAccidente {

    public static void main(String[] args) {
        
        
        float P =0;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese nombre del accidentado");
        String nombre = teclado.nextLine();
        teclado = new Scanner(System.in);
        System.out.println("INGRESE LA EDAD DEL ACCIDENTADO");
        int edad = teclado.nextInt();
        System.out.println("Ingrese el tipo de actividad");
        System.out.println("ESTUDIANTE, TRABAADOR O ESTRELLA");
        teclado = new Scanner(System.in);
        String actividad = teclado.nextLine();
       
       
        actividad = actividad.toLowerCase();
        int preciotrabajo=0;
        
        if(actividad.equals("estudiante")){
            preciotrabajo+=1000000;
        }
        if(actividad.equals("trabajador")){
            preciotrabajo+=6000000;
        }
        if(actividad.equals("estrella")){
            preciotrabajo+=50000000;
        }
        
        System.out.println("Las cuales son 1 Fractura, 2 cuadraplejico, 3 muerte");
 
       float fractura = 0.35f;
       float cuadraplejico = 0.40f;
       float muerto= 1;
       float tiempoaños = 80-edad;
       float tiempomes =12 *tiempoaños ;
       float tiempodias= 30*tiempomes;
       
        int opcion = teclado.nextInt();
        switch (opcion) {
            case 1:
             P = preciotrabajo*fractura;
                break;
            case 2:
             P = preciotrabajo*cuadraplejico;
                break;
            case 3:
             P = preciotrabajo*muerto;
             break;
            default:
             System.out.println("Ingrese las opciones en el listado Las opciones son 1, 2, 3 ");
             break;
        }
        
        System.out.println("Las persona "+nombre+" con la edad de "+edad+" el cual tuvo un accidente/n"
                + "recibira mensualmente un prejuicio mensual por su accidente ");
        System.out.println("la cantidad de dinero que recibira es de: $"+P+" pesos ");
        System.out.println("y el tiempo que le queda en años es de "+tiempoaños+" en años/n"
                    + "el tiepo que le queda en meses es de "+tiempomes+" y le quedan en dias es/n"
                    +"de "+ tiempodias+" dias ");
      
        
        
      
        
        
        
        
    }
    
}
