/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicionotas;

import java.util.Scanner;

/**
 *
 * @author JoLuuu
 */
public class EjercicioNotas {

    public static void main(String[] args) {
     
        double N1;
        double N2;
        double N3;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese nombre del estudiante");
        String nombre = teclado.nextLine();
        System.out.println("Ingrese apellido del estudiante");
        String apellido = teclado.nextLine();
        teclado = new Scanner(System.in);
        System.out.println("Ingrese la edad");
        int edad = teclado.nextInt();
        System.out.println("Ingrese semestre");
        teclado = new Scanner(System.in);
        String semestre = teclado.nextLine();
        System.out.println("le calcularemos el promedio de Notas");
        System.out.println("ingre la Nota 1");
        N1 = teclado.nextDouble();
        System.out.println("ingre la Nota 2");
        N2 = teclado.nextDouble();
        System.out.println("ingre la Nota 3");
        N3 = teclado.nextDouble();
        
        double finalnota = (N1+N2+N3)/3;
        int Taños = 80-edad;
        int meses = Taños*12;
        int dias= meses*30;
        
        System.out.println("El estudiante de "+semestre+" semestre con nombre "+nombre+" "+apellido+"\n"
                + "el cual tiene como promedio nota final"+finalnota+" le quedan \n"+Taños+ 
                " de años "
        + "de vida, lo que equivale a "+meses+" meses y "+dias+" dias");
        
        
        
        
        
    
    }
}
