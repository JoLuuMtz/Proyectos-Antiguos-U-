/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vistas;
import Vistas.persona.VentanaAgregarPersona;
import Vistas.persona.VentanaBuscarPersona;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author JoLuuu
 */
public class VentanaPrincipal extends JFrame{
    
    
    private JMenuBar barraMenu;
    private JMenu menuSesion;
    private JMenu menuPersonas;
    private JMenu menuInvitaciones;
    private JMenu menuEventos;
    private JMenu menuAyuda;
    //Sesion
    private JMenuItem opcionMenuIniciarSesion;
    private JMenuItem opcionMenuCerrarSesion;
    private JMenuItem opcionMenuSalirSesion;
    //persona
    private JMenuItem opcionMenuAgregarPersona;
    private JMenuItem opcionMenuBuscarPersona;
    private JMenuItem opcionMenuBorrarPersona;
    private JMenuItem opcionMenuEditarPersona;
    //lista persona
    private JMenu subMenuListarPersonas;
    private JMenuItem opcionListarPersonasPorNombre;
    private JMenuItem opcionListarPersonasPorApellido;
    private JMenuItem opcionListarPersonasPorGenero;
    private JMenuItem opcionListarPersonasPorFechaDeNacimiento;
    private JMenuItem opcionListarPersonasPorEvento;
    //eventos
    private JMenuItem opcionMenuAgregarEventos;
    private JMenuItem opcionMenuBorrarEventos;
    private JMenuItem opcionMenuBuscarEventos;
    private JMenuItem opcionMenuEditarEventos;
    //listaEventos
    private JMenu subMenuListarEventos;
    private JMenuItem opcionListarEventosPorPersona;
    private JMenuItem opcionListarEventosPorFecha;
    //invitados
    private JMenuItem opcionMenuAgregarInvitado;
    private JMenuItem opcionMenuEditarInvitado;
    private JMenuItem opcionMenuBuscarInvitado;
    private JMenuItem opcionMenuBorrarInvitado;
    //lista invitar
    private JMenu subMenuListarInvitados;
    private JMenuItem opcionListarInvitadosPorPersona;
    private JMenuItem opcionListarInvitadosPorEventos;
      
    
      
//este codigo es para arregar item por item cada menu en la ventana JFrame
    public VentanaPrincipal(){
  this.configurar();
    }  
    public void configurar(){
        
        this.barraMenu = new JMenuBar();
        this.setJMenuBar(barraMenu);
        this.menuSesion = new JMenu("Session");
        this.menuSesion.setMnemonic('S');
        this.barraMenu.add(menuSesion);
        this.opcionMenuIniciarSesion = new JMenuItem("Iniciar");
        this.opcionMenuCerrarSesion = new JMenuItem("Cerrar");
        this.opcionMenuSalirSesion = new JMenuItem("Salir");
                
//paara agregar item al menu de session
        this.menuSesion.add(this.opcionMenuIniciarSesion);
        this.menuSesion.add(this.opcionMenuSalirSesion);
        this.menuSesion.add(this.opcionMenuCerrarSesion);
        
        //Agregar el menu de Peronsas y sus repscetivos item
        
        
        this.menuPersonas = new JMenu("Persona");
        //agregar el menu persona en la barra
         this.barraMenu.add(this.menuPersonas);
        this.menuPersonas.setMnemonic('P');
        this.opcionMenuAgregarPersona = new JMenuItem("Agregar");
        this.opcionMenuBorrarPersona = new JMenuItem("Borrar");
        this.opcionMenuEditarPersona = new JMenuItem ("Editar");
        this.opcionMenuBuscarPersona = new JMenuItem ("Buscar");
        //Agregar menuItem al menu de Persona
        this.menuPersonas.add(opcionMenuAgregarPersona);
         this.menuPersonas.add(opcionMenuEditarPersona);
         this.menuPersonas.add(opcionMenuBuscarPersona);
         this.menuPersonas.add(opcionMenuBorrarPersona);
         //Agreagr el subMenu Lista para el Mneu Persona
        this.subMenuListarPersonas = new JMenu("Listar");
        this.menuPersonas.add(subMenuListarPersonas);
        this.opcionListarPersonasPorNombre = new JMenuItem("Por Nombre...");
        this.opcionListarPersonasPorApellido = new JMenuItem("Por Apellido...");
        this.opcionListarPersonasPorGenero = new JMenuItem("Por Genero...");
        this.opcionListarPersonasPorFechaDeNacimiento = new JMenuItem("Por Nombre...");
        this.opcionListarPersonasPorEvento = new JMenuItem("Por Evento...");
        
      this.subMenuListarPersonas.add(this.opcionListarPersonasPorNombre);
      this.subMenuListarPersonas.add(this.opcionListarPersonasPorEvento);
      this.subMenuListarPersonas.add(this.opcionListarPersonasPorFechaDeNacimiento);
      this.subMenuListarPersonas.add(this.opcionListarPersonasPorGenero);
      this.subMenuListarPersonas.add(this.opcionListarPersonasPorApellido);
      
      this.menuEventos = new JMenu("Eventos");
      this.barraMenu.add(this.menuEventos);
       this.menuEventos.setMnemonic('E');
      this.opcionMenuAgregarEventos = new JMenuItem("Agregar");
      this.opcionMenuBorrarEventos = new JMenuItem("Borrar");
      this.opcionMenuEditarEventos = new JMenuItem("Editar");
      this.opcionMenuBuscarEventos = new JMenuItem("Buscar");
       //Agregar menuItem al menu de Eventos
   
      this.menuEventos.add(opcionMenuAgregarEventos);
      this.menuEventos.add(opcionMenuBorrarEventos);
      this.menuEventos.add(opcionMenuEditarEventos);
      this.menuEventos.add(opcionMenuBuscarEventos);
       //Agreagr el subMenu Lista para el Mneu Eventos
      this.subMenuListarEventos = new JMenu("Listar");
      this.menuEventos.add(subMenuListarEventos);
      this.opcionListarEventosPorPersona = new JMenuItem("Por Persona...");
      this.opcionListarEventosPorFecha = new JMenuItem("Por Fecha");
      
      this.subMenuListarEventos.add(this.opcionListarEventosPorPersona);
      this.subMenuListarEventos.add(this.opcionListarEventosPorFecha);
      
      this.menuInvitaciones = new JMenu("Invitados");
      this.barraMenu.add(this.menuInvitaciones);
      this.menuInvitaciones.setMnemonic('I');
      this.opcionMenuAgregarInvitado = new JMenuItem("Agregar");
      this.opcionMenuBuscarInvitado = new JMenuItem("Buscar");
      this.opcionMenuBorrarInvitado = new JMenuItem("Borrar");
      this.opcionMenuEditarInvitado = new JMenuItem("Editar");
      
      this.menuInvitaciones.add(opcionMenuAgregarInvitado);
      this.menuInvitaciones.add(opcionMenuBorrarInvitado);
      this.menuInvitaciones.add(opcionMenuEditarInvitado);
      this.menuInvitaciones.add(opcionMenuBuscarInvitado);
      
      this.subMenuListarInvitados = new JMenu("Listar");
      this.menuInvitaciones.add(subMenuListarInvitados);
      this.opcionListarInvitadosPorPersona = new JMenuItem("Por Persona...");
      this.opcionListarInvitadosPorEventos = new JMenuItem("Eventos...");
      
    this.subMenuListarInvitados.add(this.opcionListarInvitadosPorPersona);
     this.subMenuListarInvitados.add(this.opcionListarInvitadosPorEventos);
     
      this.menuAyuda = new JMenu ("Ayuda");
      this.barraMenu.add(this.menuAyuda);

    ActionListener eventoAgregarPersona = new ActionListener() {
@Override
public void actionPerformed(ActionEvent evento) {
mostrarVentanaAgregarPersona(evento);
}
};
this.opcionMenuAgregarPersona.addActionListener(eventoAgregarPersona);
ActionListener eventoBuscarPersona = new ActionListener() {
@Override
public void actionPerformed(ActionEvent evento) {
mostrarVentanaBuscarPersona(evento);
}
};
this.opcionMenuBuscarPersona.addActionListener(eventoBuscarPersona);
}
public void mostrarVentanaAgregarPersona( ActionEvent evento ){
VentanaAgregarPersona VentanaAgrgaeP = new VentanaAgregarPersona(this);
VentanaAgrgaeP.setLocationRelativeTo(this);
VentanaAgrgaeP.setVisible(true);
}


public void mostrarVentanaBuscarPersona( ActionEvent evento ){
VentanaBuscarPersona VentanaBuscarP = new VentanaBuscarPersona(this);
VentanaBuscarP.setLocationRelativeTo(this);
VentanaBuscarP.setVisible(true);
}

    }
    

     
     
     
     
      
      
      
    
        
        
    

