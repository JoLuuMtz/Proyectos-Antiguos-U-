/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jorgemartinez.AgendaJava.Modelo;

import java.awt.image.BufferedImage;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author JoLuuu
 */
public class Evento {
    
     private String id;
     private String nombre;
     private Date fechaRegistro;
     private Date fechaInicio;
     private Date fechaFin;
     private String tipo;
     private String categoria;
     private String lugar ;
     private String contacto;
     private BufferedImage imagenes[] = new BufferedImage[12];

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public BufferedImage[] getImagenes() {
        return imagenes;
    }

    public void setImagenes(BufferedImage[] imagenes) {
        this.imagenes = imagenes;
    }
     
    public String devolverDatos(){
        
         GregorianCalendar fechaRegistro = new GregorianCalendar();
         GregorianCalendar fechaInicio = new GregorianCalendar();
         GregorianCalendar fechaFin = new GregorianCalendar();
         fechaRegistro.setTime(this.getFechaRegistro());
        fechaInicio.setTime(this.getFechaInicio());
        fechaFin.setTime(this.getFechaFin());
        int añoI = fechaInicio.get(fechaInicio.YEAR);
        int mesI = fechaInicio.get(fechaInicio.MONTH);
        int diaI = fechaInicio.get(fechaInicio.DAY_OF_MONTH);
        int  añoR = fechaRegistro.get(fechaRegistro.YEAR);
        int mesR = fechaRegistro.get(fechaRegistro.MONTH);
        int diaR = fechaRegistro.get(fechaRegistro.DAY_OF_MONTH);
        int añoF = fechaFin.get(fechaFin.YEAR);
        int mesF = fechaFin.get(fechaFin.MONTH);
        int diaF = fechaFin.get(fechaFin.DAY_OF_MONTH);
         String fechaINI = añoI+" "+mesI+" "+diaI;
         String fechaReg = añoR+" "+mesR+" "+diaR;     
         String fechaF = añoF+" "+mesF+" "+diaF;  
    
    String datoEvento = "---------------------\n";
    datoEvento += "ID"+this.getId()+"\n";
    datoEvento += "Nombre del evento"+this.getNombre()+"\n";
    datoEvento += "Fecha Registro"+this.getFechaRegistro()+"\n";
    datoEvento  += "Fecha Inicio"+this.getFechaInicio()+"\n";
    datoEvento +=   "Tipo de evento"+this.getTipo()+"\n";
    datoEvento += "Categoria"+this.getCategoria()+"\n";
    datoEvento += "Lugar"+this.getLugar()+"\n";
    datoEvento += "Contacto"+this.getContacto()+"\n";
                    
     return datoEvento;  
    
    }
    @Override
    public String toString(){
        return this.devolverDatos();
    }
     
}
