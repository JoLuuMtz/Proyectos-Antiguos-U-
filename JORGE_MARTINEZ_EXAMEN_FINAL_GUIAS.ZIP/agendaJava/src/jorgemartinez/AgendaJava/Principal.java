/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jorgemartinez.AgendaJava;
import javax.swing.JFrame;
import static java.lang.reflect.Array.get;
import jorgemartinez.AgendaJava.Modelo.Persona;
import jorgemartinez.AgendaJava.Modelo.Evento;
import jorgemartinez.AgendaJava.Modelo.Invitacion;
import Vistas.VentanaPrincipal;

/**
 *
 * @author JoLuuu
 */
public class Principal {

    public static void main(String[] args) {
      
    /*Invitacion V = new Invitacion();
 
        System.out.println(V.devolverDatos());
        
     Persona P = new Persona();  
        System.out.println(P.devolverDatos());
     
       */
   VentanaPrincipal  V = new VentanaPrincipal();
   V.setVisible(true);
   V.setExtendedState(JFrame.MAXIMIZED_BOTH);
   V.setTitle("Agenda Electornica");
   
   
  
   
}
}



