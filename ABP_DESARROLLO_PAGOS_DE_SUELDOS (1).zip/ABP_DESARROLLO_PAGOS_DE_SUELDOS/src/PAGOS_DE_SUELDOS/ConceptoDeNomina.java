/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PAGOS_DE_SUELDOS;

public class ConceptoDeNomina {

    private double percepcionesSalariales;
    private double deduccionesDeLaNomina;

    public double getPercepcionesSalariales() {
        return percepcionesSalariales;
    }

    public void setPercepcionesSalariales(double percepcionesSalariales) {
        this.percepcionesSalariales = percepcionesSalariales;
    }

    public double getDeduccionesDeLaNomina() {
        return deduccionesDeLaNomina;
    }

    public void setDeduccionesDeLaNomina(double deduccionesDeLaNomina) {
        this.deduccionesDeLaNomina = deduccionesDeLaNomina;
    }

    private double categoria;
    private double puestoDeDestino;

    public double getPuestoDeDestino() {
        return puestoDeDestino;
    }

    public void setPuestoDeDestino(double puestoDeDestino) {
        this.puestoDeDestino = puestoDeDestino;
        percepcionesSalariales += puestoDeDestino;
    }

    public double getCategoria() {
        return categoria;
    }

    public void setCategoria(double Categoria) {
        this.categoria = Categoria;

    }
    
    
    
}
