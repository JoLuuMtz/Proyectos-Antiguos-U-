/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PAGOS_DE_SUELDOS;

import java.util.Date;

public class Antiguedad {

    Date dt = new Date();
    private Date fechaDeIngreso;
    private double importePorTrienios;
    private int añoInicio;
    private int añoHoy;
    private int mesInicio;
    private int mesHoy;
    private int diaInicio;
    private int diaHoy;
    private int añosTrabajados;
    private int mesesTrabajados;
    private int diasTrabajados;
   
    public int getAñosTrabajados() {
        return añosTrabajados;

    }

    public void setAñosTrabajados(int añosTrabajados) {
        this.añosTrabajados = añosTrabajados;
    }

    public int getMesesTrabajados() {
        return mesesTrabajados;
    }

    public void setMesesTrabajados(int mesesTrabajados) {
        this.mesesTrabajados = mesesTrabajados;
    }

    public int getDiasTrabajados() {
        return diasTrabajados;
    }

    public void setDiasTrabajados(int diasTrabajados) {
        this.diasTrabajados = diasTrabajados;
    }

    public int getAñoInicio() {
        return añoInicio;
    }

    public void setAñoInicio(int añoInicio) {
        this.añoInicio = añoInicio;
    }

    public int getAñoHoy() {
        return añoHoy;
    }

    public void setAñoHoy(int añoFin) {
        this.añoHoy = añoFin;
    }

    public int getMesInicio() {
        return mesInicio;
    }

    public void setMesInicio(int mesInicio) {
        this.mesInicio = mesInicio;
    }

    public int getMesHoy() {
        return mesHoy;
    }

    public void setMesHoy(int mesFin) {
        this.mesHoy = mesFin;
    }

    public int getDiaInicio() {
        return diaInicio;
    }

    public void setDiaInicio(int diaInicio) {
        this.diaInicio = diaInicio;
    }

    public int getDiaHoy() {
        return diaHoy;
    }

    public void setDiaHoy(int diaFin) {
        this.diaHoy = diaFin;
    }

    public Date getfechaDeIngreso() {
        return fechaDeIngreso;
    }

    public void setfechaDeIngreso(Date fechaDeIngreso) {
        this.fechaDeIngreso = fechaDeIngreso;
    }

    public double getImportePorTrienios() {
        return importePorTrienios;
    }

    public void setImportePorTrienios(double importePorTrienios) {
        this.importePorTrienios = importePorTrienios;
    }

}
