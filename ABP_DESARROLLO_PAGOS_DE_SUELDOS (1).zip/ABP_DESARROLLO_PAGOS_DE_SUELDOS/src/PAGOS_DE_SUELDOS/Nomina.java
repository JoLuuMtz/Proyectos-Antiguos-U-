/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PAGOS_DE_SUELDOS;

public class Nomina {

    double seguroSocial;
    double apórtaciones;
    double impuestoSobreRenta;

    public double getSeguroSocial() {
        return seguroSocial;
    }

    public void setSeguroSocial(double seguroSocial) {
        this.seguroSocial = seguroSocial;
    }

    public double getApórtaciones() {
        return apórtaciones;
    }

    public void setApórtaciones(double apórtaciones) {
        this.apórtaciones = apórtaciones;
    }

    public double getImpuestoSobreRenta() {
        return impuestoSobreRenta;
    }

    public void setImpuestoSobreRenta(double impuestoSobreRenta) {
        this.impuestoSobreRenta = impuestoSobreRenta;
    }
}
