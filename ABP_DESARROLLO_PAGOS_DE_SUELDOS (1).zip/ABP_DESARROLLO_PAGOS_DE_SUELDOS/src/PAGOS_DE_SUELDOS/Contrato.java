/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PAGOS_DE_SUELDOS;

import java.util.Date;

public class Contrato {

    private String id;
    private Date fechaAlta;
    private Date fechaBaja;
    private String categoria;
    private String puestoDeDestino;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getPuestoDeDestino() {
        return puestoDeDestino;
    }

    public void setPuestoDeDestino(String puestoDeDestino) {
        this.puestoDeDestino = puestoDeDestino;
    }

    public Date getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaALta(Date fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public Date getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(Date fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

}
